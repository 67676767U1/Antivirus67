package com.example.antivirusprank

import android.app.Activity
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.graphics.Color
import android.graphics.Typeface
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView

class MainActivity : Activity() {
    private val handler = Handler(Looper.getMainLooper())
    private lateinit var status: TextView
    private lateinit var progress: ProgressBar
    private lateinit var action: Button
    private var step = 0

    private val messages = listOf(
        "Подготовка демонстрационной проверки…",
        "Проверка файлов (демо)…",
        "Анализ приложений (демо)…",
        "Проверка завершена"
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.setFlags(
            WindowManager.LayoutParams.FLAG_FULLSCREEN,
            WindowManager.LayoutParams.FLAG_FULLSCREEN
        )
        window.statusBarColor = Color.rgb(145, 0, 0)
        window.navigationBarColor = Color.BLACK
        showScanner()
    }

    private fun showScanner() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(28, 34, 28, 28)
            setBackgroundColor(Color.rgb(170, 0, 0))
        }

        val title = TextView(this).apply {
            text = "🛡  АНТИВИРУС"
            textSize = 30f
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
        }
        root.addView(title, matchWrap())

        val demo = TextView(this).apply {
            text = "ДЕМОНСТРАЦИОННЫЙ РЕЖИМ"
            textSize = 12f
            setTextColor(Color.rgb(255, 220, 220))
            gravity = Gravity.CENTER
            setPadding(0, 10, 0, 36)
        }
        root.addView(demo, matchWrap())

        status = TextView(this).apply {
            text = messages[0]
            textSize = 20f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            setPadding(0, 12, 0, 24)
        }
        root.addView(status, matchWrap())

        progress = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 100
            progress = 0
        }
        root.addView(progress, LinearLayout.LayoutParams(-1, 14).apply {
            bottomMargin = 24
        })

        val note = TextView(this).apply {
            text = "Это безопасная имитация. Приложение не сканирует устройство, не ищет реальные угрозы и не изменяет файлы."
            textSize = 14f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            setPadding(0, 10, 0, 28)
        }
        root.addView(note, matchWrap())

        action = Button(this).apply {
            text = "Остановить демонстрацию"
            setTextColor(Color.rgb(150, 0, 0))
            setOnClickListener { showReveal() }
        }
        root.addView(action, LinearLayout.LayoutParams(-1, -2))

        setContentView(root)
        runDemo()
    }

    private fun runDemo() {
        handler.postDelayed(object : Runnable {
            override fun run() {
                if (step >= messages.size || !::status.isInitialized) return
                status.text = messages[step]
                progress.progress = (step + 1) * 25
                step++
                if (step < messages.size) handler.postDelayed(this, 1300)
                else action.text = "Показать результат"
            }
        }, 900)
    }

    private fun showReveal() {
        handler.removeCallbacksAndMessages(null)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(28, 28, 28, 28)
            setBackgroundColor(Color.rgb(24, 120, 65))
        }
        val heading = TextView(this).apply {
            text = "Всё в порядке!"
            textSize = 30f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
        }
        root.addView(heading, matchWrap())
        val body = TextView(this).apply {
            text = "Это был розыгрыш 🙂\n\nНикаких вирусов не обнаруживалось. Приложение ничего не сканировало и не меняло на телефоне."
            textSize = 18f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            setPadding(0, 24, 0, 30)
        }
        root.addView(body, matchWrap())
        val button = Button(this).apply {
            text = "Запустить снова"
            setOnClickListener {
                handler.removeCallbacksAndMessages(null)
                step = 0
                showScanner()
            }
        }
        root.addView(button, LinearLayout.LayoutParams(-1, -2))
        setContentView(root)
    }

    private fun matchWrap() = LinearLayout.LayoutParams(-1, -2)
}
